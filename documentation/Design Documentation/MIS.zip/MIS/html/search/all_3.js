var searchData=
[
  ['checkcolumn',['checkColumn',['../class_logic_1_1_logic.html#a95254ef8de4eb1766c7b4308069a3377',1,'Logic::Logic']]],
  ['color',['color',['../class_tile_1_1_tile.html#aef5562e330fce367a8fdb889e8863a0b',1,'Tile::Tile']]],
  ['colourmatch',['colourMatch',['../class_logic_1_1_logic.html#afcaea80499c002d4326143bb2e06587e',1,'Logic::Logic']]]
];
