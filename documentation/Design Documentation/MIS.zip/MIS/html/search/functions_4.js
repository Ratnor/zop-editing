var searchData=
[
  ['movedown',['moveDown',['../class_logic_1_1_logic.html#aeabb4007e06af2811eddf4dd6c3c18c0',1,'Logic::Logic']]]
];
