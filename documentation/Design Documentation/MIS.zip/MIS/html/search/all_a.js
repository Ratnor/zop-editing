var searchData=
[
  ['userinput',['userInput',['../class_logic_1_1_logic.html#a9dac284e6cf56f92a95ff856d776b604',1,'Logic::Logic']]]
];
