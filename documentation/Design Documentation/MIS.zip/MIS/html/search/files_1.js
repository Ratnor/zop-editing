var searchData=
[
  ['logic_2epy',['Logic.py',['../_logic_8py.html',1,'']]]
];
