var searchData=
[
  ['addtile',['addTile',['../class_logic_1_1_logic.html#a172729a0c6a377b3066a14fadc1f9f76',1,'Logic::Logic']]],
  ['adjacent',['adjacent',['../class_logic_1_1_logic.html#afb04887b209c35f53ab34a85ef4f8e93',1,'Logic::Logic']]]
];
