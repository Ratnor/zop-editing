var searchData=
[
  ['logic',['Logic',['../class_logic_1_1_logic.html',1,'Logic']]]
];
