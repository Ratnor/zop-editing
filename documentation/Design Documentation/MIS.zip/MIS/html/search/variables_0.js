var searchData=
[
  ['board',['board',['../class_board_1_1_board.html#ad18dab28d51fbe8bbf93036546741a0b',1,'Board.Board.board()'],['../class_main_1_1_main.html#a6591a0b754645446e057a38d9760da13',1,'Main.Main.board()']]]
];
