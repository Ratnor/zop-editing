var searchData=
[
  ['logic',['Logic',['../class_logic_1_1_logic.html',1,'Logic']]],
  ['logic',['Logic',['../namespace_logic.html',1,'Logic'],['../class_main_1_1_main.html#a88f0c33b72e0c217e6af6e3064d7db14',1,'Main.Main.logic()']]],
  ['logic_2epy',['Logic.py',['../_logic_8py.html',1,'']]]
];
