var searchData=
[
  ['logic',['logic',['../class_main_1_1_main.html#a88f0c33b72e0c217e6af6e3064d7db14',1,'Main::Main']]]
];
