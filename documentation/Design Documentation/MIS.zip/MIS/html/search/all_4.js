var searchData=
[
  ['getboard',['getBoard',['../class_board_1_1_board.html#abc0eb8a2cc667bb79692d7a31cb8d508',1,'Board::Board']]],
  ['getcolor',['getColor',['../class_tile_1_1_tile.html#a7650cf3d70799ecb9544b8113a834f1a',1,'Tile::Tile']]]
];
