var searchData=
[
  ['logic',['Logic',['../namespace_logic.html',1,'']]]
];
