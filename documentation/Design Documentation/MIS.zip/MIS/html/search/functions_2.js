var searchData=
[
  ['checkcolumn',['checkColumn',['../class_logic_1_1_logic.html#a95254ef8de4eb1766c7b4308069a3377',1,'Logic::Logic']]],
  ['colourmatch',['colourMatch',['../class_logic_1_1_logic.html#afcaea80499c002d4326143bb2e06587e',1,'Logic::Logic']]]
];
