var searchData=
[
  ['_5f_5finit_5f_5f',['__init__',['../class_board_1_1_board.html#ab3b70b36f866ec130f9d8d6af9976308',1,'Board.Board.__init__()'],['../class_tile_1_1_tile.html#aa9ea504c46b54d4f3d55eaa9fbd15ed3',1,'Tile.Tile.__init__()']]]
];
