var searchData=
[
  ['main',['Main',['../class_main_1_1_main.html',1,'Main']]],
  ['main',['Main',['../namespace_main.html',1,'']]],
  ['main_2epy',['Main.py',['../_main_8py.html',1,'']]],
  ['movedown',['moveDown',['../class_logic_1_1_logic.html#aeabb4007e06af2811eddf4dd6c3c18c0',1,'Logic::Logic']]]
];
